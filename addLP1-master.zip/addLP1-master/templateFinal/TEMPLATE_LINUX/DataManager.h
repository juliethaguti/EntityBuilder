#define ARCHIVO_SOCIOS "socios.bin"

int dm_saveAllX(ArrayList* pArrayX);
int dm_readAllX(ArrayList* pArrayX);
