#include <stdio.h>
#include <stdlib.h>
#include "Controlador.h"

int main()
{
    cont_init();
    return 0;

}
